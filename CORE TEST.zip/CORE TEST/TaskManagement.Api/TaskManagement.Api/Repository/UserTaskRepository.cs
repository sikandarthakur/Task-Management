﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using TaskManagement.Models;

namespace TaskManagement.Api.Repository
{
    public class UserTaskRepository : IUserTask
    {
        private readonly TaskManagementDBContext _context;

        /// <summary>
        /// TaskManagementDBContext Dependency Injection
        /// </summary>
        /// <param name="context"></param>
        public UserTaskRepository(TaskManagementDBContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Create new Task
        /// </summary>
        /// <param name="userTask"></param>
        /// <returns></returns>
        public async Task<UserTask> CreateTask(TaskViewModel taskViewModel)
        {
            UserTask userTask = new UserTask
            {
                TaskName = taskViewModel.TaskName,
                TaskDescription = taskViewModel.TaskDescription,
                StartDate = taskViewModel.StartDate,
                EndDate = taskViewModel.EndDate,
                IsOpen = taskViewModel.IsOpen,
                Status = taskViewModel.Status
            };
            var addTask = await _context.UserTasks.AddAsync(userTask);
            await _context.SaveChangesAsync();
            return addTask.Entity;
        }

        /// <summary>
        /// Delete Task
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<UserTask> DeleteTask(int id)
        {
            var selectedTask = await _context.UserTasks.FindAsync(id);
            _context.UserTasks.Remove(selectedTask);
            await _context.SaveChangesAsync();
            return selectedTask;
        }

        /// <summary>
        /// Get All Task
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<UserTask>> GetTasks()
        {
            return await _context.UserTasks.ToListAsync();
        }

        /// <summary>
        /// Update Task
        /// </summary>
        /// <param name="id"></param>
        /// <param name="userTask"></param>
        /// <returns></returns>
        public async Task<UserTask> UpdateTask(int id, TaskViewModel taskViewModel)
        {
            UserTask userTask = new UserTask
            {
                TaskName = taskViewModel.TaskName,
                TaskDescription = taskViewModel.TaskDescription,
                StartDate = taskViewModel.StartDate,
                EndDate = taskViewModel.EndDate,
                IsOpen = taskViewModel.IsOpen,
                Status = taskViewModel.Status
            };
            var selectedTask = await _context.UserTasks.FirstOrDefaultAsync(x => x.TaskId == id);
            if (selectedTask != null)
            {
                selectedTask.TaskName = userTask.TaskName;
                selectedTask.TaskDescription = userTask.TaskDescription;
                selectedTask.StartDate = userTask.StartDate;
                selectedTask.EndDate = userTask.EndDate;
                selectedTask.IsOpen = userTask.IsOpen;
                selectedTask.Status = userTask.Status;
            }
            _context.SaveChanges();
            return selectedTask;
        }
    }
}
