import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { TaskManagementService } from 'src/app/shared/task-management.service';

@Component({
  selector: 'app-task-management',
  templateUrl: './task-management.component.html',
  styleUrls: ['./task-management.component.css']
})
export class TaskManagementComponent implements OnInit {

  constructor(public myservice:TaskManagementService,private toastr: ToastrService) { }

  ngOnInit(): void {
    this.myservice.GetTasks();
  }
  // OnDelete(taskId) {
  //   if (confirm('Are you sure to delete this record?')) {
  //     this.myservice.DeleteTask(taskId)
  //       .subscribe(res => {
  //         this.myservice.GetTasks();
  //         this.toastr.warning('Deleted Successfully', 'Task Management');
  //       },
  //         err => {
  //           console.log(err);
  //        })
  //   }
  // }

}
