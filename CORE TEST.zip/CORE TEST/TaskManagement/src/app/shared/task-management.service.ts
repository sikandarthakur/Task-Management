import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TaskManagement } from './task-management.model';

@Injectable({
  providedIn: 'root'
})
export class TaskManagementService {

  formData: TaskManagement = new TaskManagement();
  readonly rootURL = "http://localhost:51896/api/";
  list: TaskManagement[];

  constructor(private http: HttpClient) { }

  GetTasks() {
    this.http.get(this.rootURL + 'UserTasks')
      .toPromise()
      .then(res => this.list = res as TaskManagement[])
  }

  // DeleteTask(id) {
  //   return this.http.delete(this.rootURL + 'UserTasks/' + id)
  // }

}
