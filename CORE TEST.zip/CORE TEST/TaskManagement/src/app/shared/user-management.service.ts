import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { UserManagement } from './user-management.model';

@Injectable({
  providedIn: 'root'
})
export class UserManagementService {
  formData: UserManagement = new UserManagement();
  readonly rootURL = "http://localhost:51896/api/";
  list: UserManagement[];
  constructor(private http: HttpClient) { }

  GetUsers() {
    this.http.get(this.rootURL + 'Users').toPromise()
      .then(res => this.list = res as UserManagement[])
  }
  
}
