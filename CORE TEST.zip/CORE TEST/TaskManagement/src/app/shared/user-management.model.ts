export class UserManagement {
    userId:number=0;
    firstname:string = '';
    lastname:string = '';
}
