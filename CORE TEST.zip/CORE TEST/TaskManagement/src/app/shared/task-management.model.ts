export class TaskManagement {
        taskId:number;
        taskName:string;
        taskDescription: string;
        startDate: Date;
        endDate: Date
        isOpen: boolean;
        status: string;
        user:number;
}
