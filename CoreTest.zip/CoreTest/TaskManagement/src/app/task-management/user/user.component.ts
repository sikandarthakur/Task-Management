import { Component, OnInit } from '@angular/core';
import { TaskManagementService } from 'src/app/shared/task-management.service';
import { UserManagementService } from 'src/app/shared/user-management.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],
})
export class UserComponent implements OnInit {
  constructor(
    public userService: UserManagementService,
    public taskService: TaskManagementService
  ) {}

  ngOnInit() {
    this.userService.getUsers();
  }

  getTaskByUserId($event, userId) {
    this.taskService.getTaskByUserId($event, userId);
  }
}
