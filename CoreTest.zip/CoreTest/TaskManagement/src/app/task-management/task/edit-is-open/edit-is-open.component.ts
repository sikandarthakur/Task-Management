import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { TaskManagementService } from 'src/app/shared/task-management.service';

@Component({
  selector: 'app-edit-is-open',
  templateUrl: './edit-is-open.component.html',
  styleUrls: ['./edit-is-open.component.css'],
})
export class EditIsOpenComponent implements OnInit {
  constructor(
    public dialogRef: MatDialogRef<EditIsOpenComponent>,
    public taskService: TaskManagementService
  ) {}

  ngOnInit(): void {}

  onClose() {
    this.dialogRef.close();
  }
  onCloseTask() {
    this.taskService.isClose();
    this.onClose();
  }
}
