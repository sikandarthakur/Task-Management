import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { UserManagementService } from 'src/app/shared/user-management.service';
import { User } from 'src/app/shared/user.model';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { TaskManagementService } from 'src/app/shared/task-management.service';

@Component({
  selector: 'app-create-task',
  templateUrl: './create-task.component.html',
  styleUrls: ['./create-task.component.css'],
})
export class CreateTaskComponent implements OnInit {
  startDate = new Date();
  endDate = new Date();
  userList: User[] = [];
  formData: FormGroup;
  constructor(
    public userService: UserManagementService,
    public taskService: TaskManagementService,
    public dialogRef: MatDialogRef<CreateTaskComponent>
  ) {}

  ngOnInit(): void {
    this.userList = this.userService.userList;
    this.formData = new FormGroup({
      taskName: new FormControl('', Validators.required),
      taskDescription: new FormControl('', Validators.required),
      userId: new FormControl(''),
      startDate: new FormControl('', Validators.required),
      endDate: new FormControl('', Validators.required),
    });
  }

  onClose() {
    this.dialogRef.close();
  }

  onSubmit(task) {
    this.taskService.createTask(task);
    this.onClose();
  }
}
