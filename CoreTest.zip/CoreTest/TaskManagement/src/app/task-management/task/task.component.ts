import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { TaskManagementService } from 'src/app/shared/task-management.service';
import { Usertask } from 'src/app/shared/usertask.model';
import { CreateTaskComponent } from './create-task/create-task.component';
import { EditIsOpenComponent } from './edit-is-open/edit-is-open.component';
import { EditTaskComponent } from './edit-task/edit-task.component';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css'],
})
export class TaskComponent implements OnInit {
  constructor(
    public taskService: TaskManagementService,
    private dialog: MatDialog
  ) {}
  userTaskList: Usertask[];
  ngOnInit(): void {
    this.taskService.getUserTasks();
    this.taskService.userTaskList$.subscribe((res) => {
      this.userTaskList = res;
    });
console.log("hiiiiiiiiiiii");

    console.log(this.userTaskList);
    
  }

  onCreate() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '60%';
    this.dialog.open(CreateTaskComponent, dialogConfig);
  }

  onEdit(task) {
    this.taskService.populateForm(task);
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '60%';
    this.dialog.open(EditTaskComponent, dialogConfig);
  }
  
  onCheck($event, taskId) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '60%';
    this.dialog.open(EditIsOpenComponent, dialogConfig);
    this.taskService.updateIsOpen($event, taskId);
  }

  DeleteTask(taskId) {
    if (confirm('Are you sure you want to delete?')) {
      this.taskService.DeleteTask(taskId);
    }
  }
}
