import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UserManagementService } from 'src/app/shared/user-management.service';
import { User } from 'src/app/shared/user.model';
import { TaskManagementService } from 'src/app/shared/task-management.service';

@Component({
  selector: 'app-edit-task',
  templateUrl: './edit-task.component.html',
  styleUrls: ['./edit-task.component.css'],
})
export class EditTaskComponent implements OnInit {
  startDate = new FormControl(new Date());
  endDate = new FormControl(new Date());
  formData: FormGroup;
  userList: User[] = [];
  task;

  constructor(
    public userService: UserManagementService,
    public taskService: TaskManagementService,
    public dialogRef: MatDialogRef<EditTaskComponent>
  ) {}

  ngOnInit(): void {
    this.userService.getUsers();
    this.userList = this.userService.userList;
    this.task = this.taskService.task;
    console.log(this.task);
    
    this.formData = new FormGroup({
      taskName: new FormControl('', Validators.required),
      taskDescription: new FormControl('', Validators.required),
      userId: new FormControl(''),
      startDate: new FormControl('', Validators.required),
      endDate: new FormControl('', Validators.required),
    });

    this.formData.setValue({
      taskName: this.task.taskName,
      taskDescription: this.task.taskDescription,
      startDate: this.task.startDate,
      endDate: this.task.endDate,
      userId: this.task.userId,
    });

  }

  onClose() {
    this.dialogRef.close();
  }

  onSubmit(task) {
    this.taskService.updateTask(task);
    this.onClose();
  }
}
