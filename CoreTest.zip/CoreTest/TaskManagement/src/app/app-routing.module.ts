import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { TaskManagementComponent } from './task-management/task-management.component';

const routes: Routes = [
  { path: '', redirectTo: 'task-management', pathMatch: 'full' },
  { path: 'task-management', component: TaskManagementComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
export const RoutingComponent = [
  TaskManagementComponent,
  HeaderComponent,
  FooterComponent
]
