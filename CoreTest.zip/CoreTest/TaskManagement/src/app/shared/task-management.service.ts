import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Usertask } from './usertask.model';

@Injectable({
  providedIn: 'root',
})
export class TaskManagementService {
  taskData: Usertask = new Usertask();
  readonly userTaskApiUrl = 'https://localhost:44346/api/UserTasks/';
  taskList: Usertask[]; // all tasks
  userTaskList: Usertask[] = [];
  userTaskList$ = new BehaviorSubject<Usertask[]>([]);
  isAvailable: boolean = false;
  task: Usertask;
  $event;
  taskId;
  getTask: Usertask;
  pipe = new DatePipe('en-US');
  enddate;
  todaysdate;
  constructor(private _http: HttpClient) {}

  getUserTasks() {
    this._http.get(`${this.userTaskApiUrl}`).subscribe((res) => {
      this.taskList = res as Usertask[];
    });
  }

  getTaskById(taskId) {
    this._http
      .get(`${this.userTaskApiUrl}${taskId}`)
      .toPromise()
      .then((res) => {
        this.getTask = res as Usertask;
        console.log(this.getTask);
      });
  }

  getTaskByUserId($event, userId) {
    if ($event) {
      this.getUserTasks();

      this._http.get(`${this.userTaskApiUrl}`).subscribe((res) => {
        this.taskList = res as Usertask[];
        this.taskList.forEach((e) => {
          if (e.userId == userId) {
            let endDate = new Date(
              this.pipe.transform(e.endDate, 'MM/dd/yyyy')
            );
            let currentDate = new Date(
              this.pipe.transform(new Date(), 'MM/dd/yyyy')
            );
            if (endDate < currentDate) {
              e.status = 'Expired';
            } else {
              e.status = 'Active';
            }
            this.onUpdateDateStatus(e);
            this.isAvailable = true;
            this.userTaskList.push(e); 
 
       
            this.userTaskList$.next(this.userTaskList);
          }
        });
      });
    } else {
      this.userTaskList = this.userTaskList.filter((f) => f.userId != userId);
      this.userTaskList$.next(this.userTaskList);
    }
    if (this.userTaskList.length == 0) {
      this.isAvailable = false;
    }
    console.log(this.userTaskList);
  }

  onUpdateDateStatus(data) {
    var t = {
      taskName: data.taskName,
      taskDescription: data.taskDescription,
      startDate: data.startDate,
      endDate: data.endDate,
      isOpen: true,
      status: data.status,
      userId: data.userId,
    };
    this._http.put(this.userTaskApiUrl + data.taskId, t).subscribe((res) => {
      // console.log(res);
    });
  }

  createTask(task) {
    var postTask = {
      taskName: task.taskName,
      taskDescription: task.taskDescription,
      startDate: task.startDate,
      endDate: task.endDate,
      userId: +task.userId,
    };

    this._http.post(this.userTaskApiUrl, postTask).subscribe((res) => {
      var task = {
        taskId: res['taskId'],
        taskName: res['taskName'],
        taskDescription: res['taskDescription'],
        startDate: res['startDate'],
        endDate: res['endDate'],
        isOpen: res['isOpen'],
        status: res['status'],
        userId: res['userId'],
        firstname: res['firstName'],
        lastname: res['lastName'],
      };
      this.userTaskList.push(task);
    });
  }

  populateForm(task) {
    this.task = task;
  }

  updateTask(task) {
    var updateUserTask = {
      taskName: task.taskName,
      taskDescription: task.taskDescription,
      startDate: task.startDate,
      endDate: task.endDate,
      isOpen: true,
      status: 'Active',
      userId: +task.userId,
    };

    this._http
      .put(`${this.userTaskApiUrl}${this.task.taskId}`, updateUserTask)
      .subscribe((res) => {
        console.log(res);
      });
  }

  updateIsOpen($event, taskId) {
    this.$event = $event;
    this.taskId = taskId;
  }

  isClose() {
    this._http
      .get(`${this.userTaskApiUrl}${this.taskId}`)
      .toPromise()
      .then((res) => {
        this.getTask = res as Usertask;
        if (this.$event) {
          var t = {
            taskName: this.getTask.taskName,
            taskDescription: this.getTask.taskDescription,
            startDate: this.getTask.startDate,
            endDate: this.getTask.endDate,
            isOpen: true,
            status: 'Active',
            userId: +this.getTask.userId,
          };

          this._http
            .put(`${this.userTaskApiUrl}${this.getTask.taskId}`, t)
            .subscribe((res) => {
              console.log(res);
            });
        } else {
          var t = {
            taskName: this.getTask.taskName,
            taskDescription: this.getTask.taskDescription,
            startDate: this.getTask.startDate,
            endDate: this.getTask.endDate,
            isOpen: false,
            status: 'Active',
            userId: +this.getTask.userId,
          };
          this._http
            .put(`${this.userTaskApiUrl}${this.getTask.taskId}`, t)
            .subscribe((res) => {
              console.log(res);
            });
        }
      });
  }

  DeleteTask(taskId) {
    this._http.delete(`${this.userTaskApiUrl}${taskId}`).subscribe((res) => {});
    this.userTaskList.forEach((t) => {
      if (t.taskId == taskId) {
        let index = this.userTaskList.indexOf(t);
        if (index != -1) {
          this.userTaskList.splice(index, 1);
          this.userTaskList$.next(this.userTaskList);
        }
      }
    });
  }
}
