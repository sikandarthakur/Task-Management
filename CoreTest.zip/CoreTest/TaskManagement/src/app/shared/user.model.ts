export class User {
  userId: number;
  firstname: string;
  lastname: string;
}
