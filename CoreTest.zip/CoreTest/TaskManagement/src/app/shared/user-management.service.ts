import { Injectable } from '@angular/core';
import { User } from './user.model';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class UserManagementService {
  userData: User = new User();
  readonly userApiUrl = 'https://localhost:44346/api';
  userList: User[];

  constructor(private _http: HttpClient) {}

  getUsers() {
    this._http.get(`${this.userApiUrl}/Users`).subscribe((res) => {
      this.userList = res as User[];
    });
  }
}
