export class Usertask {
    taskId: number;
    userId: number;
    taskName: string;
    taskDescription: string;
    startDate: Date;
    endDate: Date;
    isOpen: boolean;
    status: string;
    firstname: string;
    lastname: string;
}
