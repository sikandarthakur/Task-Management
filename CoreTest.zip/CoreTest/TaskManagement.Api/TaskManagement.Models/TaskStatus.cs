﻿namespace TaskManagement.Models
{
    public enum TaskStatus
    {
        Active = 1,
        Expired = 0
    }
}
