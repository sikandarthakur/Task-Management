﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TaskManagement.Api.Dtos;
using TaskManagement.Models;

namespace TaskManagement.Api.Repository
{
    public interface IUserTask
    {
        Task<IEnumerable<ReadUserTaskDto>> GetTasks();

        Task<ReadUserTaskDto> GetTaskById(int taskId);

        Task<UserTask> CreateTask(CreateUserTaskDto createUserTaskDto);

        Task<UserTask> UpdateTask(int taskId, UpdateUserTaskDto updateUserTaskDto);

        Task<UserTask> DeleteTask(int taskId);
    }
}
