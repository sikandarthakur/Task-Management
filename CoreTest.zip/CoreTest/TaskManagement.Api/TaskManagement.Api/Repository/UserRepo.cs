﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using TaskManagement.Models;

namespace TaskManagement.Api.Repository
{
    public class UserRepo : IUser
    {

        private readonly TaskManagementContext _context;

        public UserRepo(TaskManagementContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Get Users
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<User>> GetUsers()
        {
            return await _context.Users.ToListAsync();
        }

        /// <summary>
        /// Get User By Id
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<User> GetUserById(int userId)
        {
            return await _context.Users.FindAsync(userId);
        }

        /// <summary>
        /// Create User
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<User> CreateUser(User user)
        {
            var userResult = await _context.Users.AddAsync(user);
            await _context.SaveChangesAsync();
            return userResult.Entity;
        }

        /// <summary>
        /// Update User
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<User> UpdateUser(int userId, User user)
        {
            var userResult = await _context.Users.FindAsync(userId);

            if (userResult != null)
            {
                userResult.Firstname = user.Firstname;
                userResult.Lastname = user.Lastname;
                await _context.SaveChangesAsync();
            }

            return userResult;
        }

        /// <summary>
        /// Delete User
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<User> DeleteUser(int userId)
        {
            var userResult = await _context.Users.FindAsync(userId);
            _context.Remove(userResult);
            await _context.SaveChangesAsync();

            return userResult;
        }
    }
}
