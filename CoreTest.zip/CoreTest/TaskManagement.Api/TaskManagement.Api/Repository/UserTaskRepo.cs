﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TaskManagement.Api.Dtos;
using TaskManagement.Models;
using TaskStatus = TaskManagement.Models.TaskStatus;

namespace TaskManagement.Api.Repository
{
    public class UserTaskRepo : IUserTask
    {

        private readonly TaskManagementContext _context;

        public UserTaskRepo(TaskManagementContext context)
        {
            _context = context;
        }


        /// <summary>
        /// Get Tasks
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<ReadUserTaskDto>> GetTasks()
        {
            return await _context.UserTasks.Select(s => new ReadUserTaskDto
            {
                TaskId = s.TaskId,
                TaskName = s.TaskName,
                TaskDescription = s.TaskDescription,
                StartDate = s.StartDate,
                EndDate = s.EndDate,
                IsOpen = s.IsOpen,
                Status = s.Status,
                UserId = s.User.UserId,
                Firstname = s.User.Firstname,
                Lastname = s.User.Lastname,
            }).ToListAsync();
        }


        /// <summary>
        /// Get Task By Id
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        public async Task<ReadUserTaskDto> GetTaskById(int taskId)
        {
            return await _context.UserTasks.Select(s => new ReadUserTaskDto
            {
                TaskId = s.TaskId,
                TaskName = s.TaskName,
                TaskDescription = s.TaskDescription,
                StartDate = s.StartDate,
                EndDate = s.EndDate,
                IsOpen = s.IsOpen,
                Status = s.Status,
                UserId = s.User.UserId,
                Firstname = s.User.Firstname,
                Lastname = s.User.Lastname,
            }).FirstOrDefaultAsync(x => x.TaskId == taskId);
        }


        /// <summary>
        /// Create Task
        /// </summary>
        /// <param name="userTask"></param>
        /// <returns></returns>
        public async Task<UserTask> CreateTask(CreateUserTaskDto createUserTaskDto)
        {
            User userResult;

            if (createUserTaskDto.UserId == 0)
            {
                userResult = null;
            }
            else
            {
                userResult = await _context.Users.FirstOrDefaultAsync(x => x.UserId == createUserTaskDto.UserId);
            }

            UserTask userTask = new UserTask()
            {
                TaskName = createUserTaskDto.TaskName,
                TaskDescription = createUserTaskDto.TaskDescription,
                StartDate = createUserTaskDto.StartDate,
                EndDate = createUserTaskDto.EndDate,
                IsOpen = true,
                Status = TaskStatus.Active.ToString(),
                User = userResult
            };

            var userTaskResult = await _context.AddAsync(userTask);
            await _context.SaveChangesAsync();

            return userTaskResult.Entity;
        }


        /// <summary>
        /// Update Task
        /// </summary>
        /// <param name="taskId"></param>
        /// <param name="userTask"></param>
        /// <returns></returns>
        public async Task<UserTask> UpdateTask(int taskId, UpdateUserTaskDto updateUserTaskDto)
        {
            var userTaskResult = await _context.UserTasks.FindAsync(taskId);
            User userResult = await _context.Users.FirstOrDefaultAsync(x => x.UserId == updateUserTaskDto.UserId);
            if (userTaskResult != null)
            {

                userTaskResult.TaskName = updateUserTaskDto.TaskName;
                userTaskResult.TaskDescription = updateUserTaskDto.TaskDescription;
                userTaskResult.StartDate = updateUserTaskDto.StartDate;
                userTaskResult.EndDate = updateUserTaskDto.EndDate;
                userTaskResult.IsOpen = updateUserTaskDto.IsOpen;
                userTaskResult.Status = TaskStatus.Active.ToString();
                userTaskResult.User = userResult;
                await _context.SaveChangesAsync();
            }

            return userTaskResult;
        }


        /// <summary>
        /// Delete Task
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        public async Task<UserTask> DeleteTask(int taskId)
        {
            var userTaskResult = await _context.UserTasks.FindAsync(taskId);
            _context.Remove(userTaskResult);
            await _context.SaveChangesAsync();

            return userTaskResult;
        }
    }
}

