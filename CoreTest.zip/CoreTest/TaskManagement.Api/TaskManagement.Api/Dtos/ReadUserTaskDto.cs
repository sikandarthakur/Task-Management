﻿using System;

namespace TaskManagement.Api.Dtos
{
    public class ReadUserTaskDto
    {
        public int TaskId { get; set; }

        public string TaskName { get; set; }

        public string TaskDescription { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public bool IsOpen { get; set; }

        public string Status { get; set; }

        public int UserId { get; set; }

        public string Firstname { get; set; }

        public string Lastname { get; set; }
    }
}
