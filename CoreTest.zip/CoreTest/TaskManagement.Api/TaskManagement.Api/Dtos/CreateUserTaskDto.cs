﻿using System;

namespace TaskManagement.Api.Dtos
{
    public class CreateUserTaskDto
    {
        public string TaskName { get; set; }

        public string TaskDescription { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public int? UserId { get; set; }
    }
}
