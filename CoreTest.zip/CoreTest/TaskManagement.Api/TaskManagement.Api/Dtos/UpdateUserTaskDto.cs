﻿using System;

namespace TaskManagement.Api.Dtos
{
    public class UpdateUserTaskDto
    {
        public int UserId { get; set; }

        public string TaskName { get; set; }

        public string TaskDescription { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public bool IsOpen { get; set; }
        public string Status { get; set; }
    }
}
