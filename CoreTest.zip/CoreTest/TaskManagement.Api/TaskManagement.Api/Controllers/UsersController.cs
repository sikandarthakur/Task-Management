﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TaskManagement.Api.Repository;
using TaskManagement.Models;

namespace TaskManagement.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUser _context;

        public UsersController(IUser context)
        {
            _context = context;
        }


        #region HttpGet
        /// <summary>
        /// Get Users
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<User>>> GetUsers()
        {
            try
            {
                return Ok(await _context.GetUsers());
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status404NotFound, "Error retrieving all users data from the database");
            }
        }



        /// <summary>
        /// Get User By Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        public async Task<ActionResult<User>> GetUserById(int id)
        {
            var userResult = await _context.GetUserById(id);
            if (userResult != null)
            {
                return Ok(userResult);
            }
            return StatusCode(StatusCodes.Status404NotFound, $"Requested id - {id} is not found");
        }
        #endregion


        #region HttpPost
        /// <summary>
        /// Create User
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ActionResult<User>> CreateUser(User user)
        {
            try
            {
                await _context.CreateUser(user);

                return CreatedAtAction(nameof(GetUserById), new { id = user.UserId }, user);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status400BadRequest, "Error retrieving all employees data from the database");
            }
        }
        #endregion


        #region HttpPut
        /// <summary>
        /// Update User
        /// </summary>
        /// <param name="id"></param>
        /// <param name="user"></param>
        /// <returns></returns>
        [HttpPut("{id}")]
        public async Task<ActionResult<User>> UpdateUser(int id, User user)
        {
            var validUserId = _context.GetUserById(id);
            if (validUserId.Result == null)
            {
                return NotFound();
            }
            else
            {
                try
                {
                    var userResult = await _context.UpdateUser(id, user);
                    return Ok(userResult);
                }
                catch (Exception)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, "Error while creating employee in database");
                }
            }
        }
        #endregion


        #region HttpDelete
        [HttpDelete]
        public async Task<ActionResult<User>> DeleteUser(int id)
        {
            try
            {
                await _context.DeleteUser(id);
                return NoContent();
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status404NotFound, $"Requested id - {id} is not found");
            }
        }
        #endregion
    }
}
