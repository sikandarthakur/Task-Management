﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TaskManagement.Api.Dtos;
using TaskManagement.Api.Repository;
using TaskManagement.Models;

namespace TaskManagement.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserTasksController : ControllerBase
    {
        private readonly IUserTask _context;

        public UserTasksController(IUserTask context)
        {
            _context = context;
        }

        #region HttpGet
        /// <summary>
        /// Get Tasks
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ReadUserTaskDto>>> GetTasks()
        {
            try
            {
                return Ok(await _context.GetTasks());
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status404NotFound, "Error retrieving all user tasks data from the database");
            }
        }


        /// <summary>
        /// Get Task By Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        public async Task<ActionResult<ReadUserTaskDto>> GetTaskById(int id)
        {
            var userTaskResult = await _context.GetTaskById(id);
            if (userTaskResult != null)
            {
                return Ok(userTaskResult);
            }

            return StatusCode(StatusCodes.Status404NotFound, $"Requested id - {id} is not found");
        }
        #endregion


        #region HttpPost
        [HttpPost]
        public async Task<ActionResult<ReadUserTaskDto>> CreateTask(CreateUserTaskDto createUserTaskDto)
        {
            try
            {
                var res = await _context.CreateTask(createUserTaskDto);
                ReadUserTaskDto task = new ReadUserTaskDto()
                {
                    TaskId = res.TaskId,
                    TaskName = res.TaskName,
                    TaskDescription = res.TaskDescription,
                    StartDate = res.StartDate,

                    EndDate = res.EndDate,
                    IsOpen = res.IsOpen,
                    Status = res.Status,
                    UserId = res.User.UserId,
                    Firstname = res.User.Firstname,
                    Lastname = res.User.Lastname
                };

                return Ok(task);
                //return CreatedAtAction(nameof(GetTaskById), new { id = userTask.TaskId }, userTask);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status400BadRequest, "Error retrieving all employees data from the database");
            }
        }
        #endregion


        #region HttpPut
        [HttpPut("{id}")]
        public async Task<ActionResult<UserTask>> UpdateTask(int id, UpdateUserTaskDto updateUserTaskDto)
        {
            var validUserTaskId = _context.GetTaskById(id);
            if (validUserTaskId.Result == null)
            {
                return NotFound();
            }
            else
            {
                try
                {
                    var userTaskeResult = await _context.UpdateTask(id, updateUserTaskDto);
                    return userTaskeResult;
                }
                catch (Exception)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, "Error while creating employee in database");
                }
            }
        }
        #endregion


        #region HttpDelete
        [HttpDelete("{id}")]
        public async Task<ActionResult<UserTask>> DeleteTask(int id)
        {
            try
            {
                await _context.DeleteTask(id);
                return NoContent();
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status404NotFound, $"Requested id - {id} is not found");
            }
        }
        #endregion
    }
}
