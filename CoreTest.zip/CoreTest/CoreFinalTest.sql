USE [TaskManagement]
GO
/****** Object:  Table [dbo].[__EFMigrationsHistory]    Script Date: 12/24/2020 5:48:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[__EFMigrationsHistory](
	[MigrationId] [nvarchar](150) NOT NULL,
	[ProductVersion] [nvarchar](32) NOT NULL,
 CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY CLUSTERED 
(
	[MigrationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[User]    Script Date: 12/24/2020 5:48:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[User](
	[UserId] [int] IDENTITY(1,1) NOT NULL,
	[Firstname] [varchar](50) NOT NULL,
	[Lastname] [varchar](50) NOT NULL,
 CONSTRAINT [PK_User] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserTask]    Script Date: 12/24/2020 5:48:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserTask](
	[TaskId] [int] IDENTITY(1,1) NOT NULL,
	[TaskName] [varchar](50) NOT NULL,
	[TaskDescription] [varchar](200) NOT NULL,
	[StartDate] [datetime] NOT NULL,
	[EndDate] [datetime] NOT NULL,
	[IsOpen] [bit] NOT NULL,
	[Status] [varchar](10) NOT NULL,
	[UserId] [int] NULL,
 CONSTRAINT [PK_UserTask] PRIMARY KEY CLUSTERED 
(
	[TaskId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
INSERT [dbo].[__EFMigrationsHistory] ([MigrationId], [ProductVersion]) VALUES (N'20201225010709_initialmigrate', N'3.1.10')
GO
SET IDENTITY_INSERT [dbo].[User] ON 
GO
INSERT [dbo].[User] ([UserId], [Firstname], [Lastname]) VALUES (1, N'Yash', N'Sonawane')
GO
INSERT [dbo].[User] ([UserId], [Firstname], [Lastname]) VALUES (2, N'Sikandar', N'Thakur')
GO
INSERT [dbo].[User] ([UserId], [Firstname], [Lastname]) VALUES (3, N'Varad', N'kale')
GO
INSERT [dbo].[User] ([UserId], [Firstname], [Lastname]) VALUES (4, N'Kalpesh', N'Patil')
GO
INSERT [dbo].[User] ([UserId], [Firstname], [Lastname]) VALUES (5, N'Saleem', N'Shaikh')
GO
INSERT [dbo].[User] ([UserId], [Firstname], [Lastname]) VALUES (6, N'Aditi', N'Ozarkar')
GO
INSERT [dbo].[User] ([UserId], [Firstname], [Lastname]) VALUES (7, N'Pranali', N'Yeole')
GO
INSERT [dbo].[User] ([UserId], [Firstname], [Lastname]) VALUES (8, N'Harshada', N'Baghal')
GO
INSERT [dbo].[User] ([UserId], [Firstname], [Lastname]) VALUES (9, N'Mansi', N'Jadhav')
GO
INSERT [dbo].[User] ([UserId], [Firstname], [Lastname]) VALUES (10, N'Bhushan', N'Ahire')
GO
SET IDENTITY_INSERT [dbo].[User] OFF
GO
SET IDENTITY_INSERT [dbo].[UserTask] ON 
GO
INSERT [dbo].[UserTask] ([TaskId], [TaskName], [TaskDescription], [StartDate], [EndDate], [IsOpen], [Status], [UserId]) VALUES (2, N'Angular', N'Task for sikandar', CAST(N'2020-12-25T18:30:00.000' AS DateTime), CAST(N'2020-12-29T18:30:00.000' AS DateTime), 1, N'Active', 2)
GO
INSERT [dbo].[UserTask] ([TaskId], [TaskName], [TaskDescription], [StartDate], [EndDate], [IsOpen], [Status], [UserId]) VALUES (6, N'Task **', N'Task of aditi', CAST(N'2020-12-23T08:35:08.560' AS DateTime), CAST(N'2020-12-23T08:35:08.560' AS DateTime), 1, N'Active', 6)
GO
INSERT [dbo].[UserTask] ([TaskId], [TaskName], [TaskDescription], [StartDate], [EndDate], [IsOpen], [Status], [UserId]) VALUES (7, N'Task 4', N'Task of Saleem', CAST(N'2020-12-23T18:30:00.000' AS DateTime), CAST(N'2020-12-24T18:30:00.000' AS DateTime), 1, N'Active', 5)
GO
INSERT [dbo].[UserTask] ([TaskId], [TaskName], [TaskDescription], [StartDate], [EndDate], [IsOpen], [Status], [UserId]) VALUES (8, N'Task 1', N'Task of Yash', CAST(N'2020-12-23T18:30:00.000' AS DateTime), CAST(N'2020-12-29T18:30:00.000' AS DateTime), 1, N'Active', 1)
GO
INSERT [dbo].[UserTask] ([TaskId], [TaskName], [TaskDescription], [StartDate], [EndDate], [IsOpen], [Status], [UserId]) VALUES (9, N'Task 1', N'Task of Varad', CAST(N'2020-12-24T18:30:00.000' AS DateTime), CAST(N'2020-12-25T18:30:00.000' AS DateTime), 1, N'Active', 3)
GO
INSERT [dbo].[UserTask] ([TaskId], [TaskName], [TaskDescription], [StartDate], [EndDate], [IsOpen], [Status], [UserId]) VALUES (10, N'Task 2 ', N'Task of yash', CAST(N'2020-12-23T18:30:00.000' AS DateTime), CAST(N'2020-12-30T18:30:00.000' AS DateTime), 1, N'Active', 1)
GO
INSERT [dbo].[UserTask] ([TaskId], [TaskName], [TaskDescription], [StartDate], [EndDate], [IsOpen], [Status], [UserId]) VALUES (11, N'Task 2', N'nadhfh', CAST(N'2020-12-23T18:30:00.000' AS DateTime), CAST(N'2020-12-22T18:30:00.000' AS DateTime), 1, N'Active', 2)
GO
INSERT [dbo].[UserTask] ([TaskId], [TaskName], [TaskDescription], [StartDate], [EndDate], [IsOpen], [Status], [UserId]) VALUES (12, N'Task 1', N'Task of Saleem', CAST(N'2020-12-29T18:30:00.000' AS DateTime), CAST(N'2021-01-19T18:30:00.000' AS DateTime), 1, N'Active', 5)
GO
INSERT [dbo].[UserTask] ([TaskId], [TaskName], [TaskDescription], [StartDate], [EndDate], [IsOpen], [Status], [UserId]) VALUES (13, N'Task 2', N'Task of Varad', CAST(N'2021-01-04T18:30:00.000' AS DateTime), CAST(N'2021-01-13T18:30:00.000' AS DateTime), 1, N'Active', 3)
GO
INSERT [dbo].[UserTask] ([TaskId], [TaskName], [TaskDescription], [StartDate], [EndDate], [IsOpen], [Status], [UserId]) VALUES (14, N'Task 1', N'Task of Kalpesh', CAST(N'2020-12-30T18:30:00.000' AS DateTime), CAST(N'2020-12-31T18:30:00.000' AS DateTime), 1, N'Active', 4)
GO
INSERT [dbo].[UserTask] ([TaskId], [TaskName], [TaskDescription], [StartDate], [EndDate], [IsOpen], [Status], [UserId]) VALUES (15, N'Task 2', N'Task of Kalpesh', CAST(N'2020-12-31T18:30:00.000' AS DateTime), CAST(N'2021-01-03T18:30:00.000' AS DateTime), 1, N'Active', 4)
GO
INSERT [dbo].[UserTask] ([TaskId], [TaskName], [TaskDescription], [StartDate], [EndDate], [IsOpen], [Status], [UserId]) VALUES (16, N'Task 1', N'Task of Harshada', CAST(N'2021-02-04T18:30:00.000' AS DateTime), CAST(N'2021-02-09T18:30:00.000' AS DateTime), 1, N'Active', 8)
GO
INSERT [dbo].[UserTask] ([TaskId], [TaskName], [TaskDescription], [StartDate], [EndDate], [IsOpen], [Status], [UserId]) VALUES (17, N'Task 2', N'Task of Harshada', CAST(N'2021-01-31T18:30:00.000' AS DateTime), CAST(N'2021-02-04T18:30:00.000' AS DateTime), 1, N'Active', 8)
GO
INSERT [dbo].[UserTask] ([TaskId], [TaskName], [TaskDescription], [StartDate], [EndDate], [IsOpen], [Status], [UserId]) VALUES (18, N'Task 1', N'Task of Bhushan', CAST(N'2020-12-23T18:30:00.000' AS DateTime), CAST(N'2020-12-25T18:30:00.000' AS DateTime), 1, N'Active', 10)
GO
INSERT [dbo].[UserTask] ([TaskId], [TaskName], [TaskDescription], [StartDate], [EndDate], [IsOpen], [Status], [UserId]) VALUES (19, N'Task 2', N'Task of Bhushan', CAST(N'2020-12-30T18:30:00.000' AS DateTime), CAST(N'2021-01-05T18:30:00.000' AS DateTime), 1, N'Active', 10)
GO
SET IDENTITY_INSERT [dbo].[UserTask] OFF
GO
ALTER TABLE [dbo].[UserTask]  WITH CHECK ADD  CONSTRAINT [FK_UserTask_User_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[User] ([UserId])
GO
ALTER TABLE [dbo].[UserTask] CHECK CONSTRAINT [FK_UserTask_User_UserId]
GO
