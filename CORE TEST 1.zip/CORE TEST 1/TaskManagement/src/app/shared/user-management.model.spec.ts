import { UserManagement } from './user-management.model';

describe('UserManagement', () => {
  it('should create an instance', () => {
    expect(new UserManagement()).toBeTruthy();
  });
});
