export class TaskManagement {
        taskId:number;
        taskName:string;
        taskDescription: string;
        startDate: string;
        endDate: string;
        isOpen: boolean;
        status: string;
        userId:number;
}
