import { TaskManagement } from './task-management.model';

describe('TaskManagement', () => {
  it('should create an instance', () => {
    expect(new TaskManagement()).toBeTruthy();
  });
});
