import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TaskManagement } from './task-management.model';

@Injectable({
  providedIn: 'root'
})
export class TaskManagementService {

  formData: TaskManagement = new TaskManagement();
  readonly rootURL = "http://localhost:51896/api/";


  taskData: TaskManagement = new TaskManagement();

  taskList: TaskManagement[]; // all tasks
  userTaskList: TaskManagement[] = [];

  constructor(private http: HttpClient) { }

  GetTasks() {
    this.http.get(this.rootURL + 'UserTasks/')
      .toPromise()
      .then(res => this.taskList= res as TaskManagement[])
  }

  DeleteTask(id) {
    return this.http.delete(this.rootURL + 'UserTasks/' + id)
  }
  AddNewTask() {
    return this.http.post(this.rootURL + 'UserTasks/', this.formData)
  }

  refreshList() {
    this.http.get(this.rootURL + 'UserTasks/')
      .toPromise()
      .then(res => this.taskList = res as TaskManagement[])
  }

  getTaskByUserId($event, userId) {
    if ($event) {
      this.taskList.forEach((e) => {
        if (e.userId == userId) {
          this.userTaskList.push(e); // selected user tasks
        }
      });
    } else {
      this.taskList.forEach((e) => {
        if (e.userId == userId) {
          let index = this.userTaskList.indexOf(e);
          if (index != -1) {
            this.userTaskList.splice(index, 1);
          }
        }
      });
    }
  }
}
