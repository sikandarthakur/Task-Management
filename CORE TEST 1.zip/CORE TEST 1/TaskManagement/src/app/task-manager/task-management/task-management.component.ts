import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { TaskManagementService } from 'src/app/shared/task-management.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms';
import {Router} from '@angular/router'

@Component({
  selector: 'app-task-management',
  templateUrl: './task-management.component.html',
  styleUrls: ['./task-management.component.css']
 
})
export class TaskManagementComponent implements OnInit {
  formdata;
  taskName;
  taskDescription;
  startDate;
  endDate;
  isOpen;
  status;
  user;

  get formControls() { return this.formdata.controls; }
  constructor(public myservice:TaskManagementService,private toastr: ToastrService,private router: Router) { }

  ngOnInit(): void {
    this.myservice.GetTasks();
  }

  OnAdd() {
    this.router.navigateByUrl('add-task');
  }
   
    // onSubmit(form: NgForm) {
    //   if (this.service.formData.pmId == 0)
    //     this.insertRecord(form);
    //   else
    //     this.updateRecord(form);
    // }
  
  //  insertRecord(form: NgForm) {
  //   this.service.postPaymentDetail().subscribe(
  //     res => {
  //       this.resetForm(form);
  //       this.toastr.success('Submitted Successfully');
  //       this.service.refreshList();
  //     },
  //     err => {
  //       console.log(err);
  //     }
  //   )
  //  }

  OnDelete(taskId) {
    if (confirm('Are you sure to delete this record?')) {
      this.myservice.DeleteTask(taskId)
        .subscribe(res => {
          this.myservice.refreshList();
          this.toastr.warning('Task Deleted Successfully');
        },
          err => {
            console.log(err);
         })
    }
  }
}


