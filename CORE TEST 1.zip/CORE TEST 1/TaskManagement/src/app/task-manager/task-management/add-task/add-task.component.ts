import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { TaskManagementService } from 'src/app/shared/task-management.service';
import { FormsModule } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent implements OnInit {

  constructor(public myservice:TaskManagementService,private toastr: ToastrService) { }

  ngOnInit(): void {
   // this.resetForm();
  }
  onSubmit(form: NgForm) {
    
    this.insertRecord(form);
   //  else
   //   this.updateRecord(form);
  }

 insertRecord(form: NgForm) {
   this.myservice.AddNewTask().subscribe(
     res => {
       //this.resetForm(form);
       this.toastr.success('Submitted Successfully');
       //this.myservice.refreshList();
     },
     err => {
       console.log(err);
     }
   )
 }
  // resetForm(form?: NgForm) {
  //   if (form != null)
  //     form.resetForm();
  //   this.myservice.formData =
  //   {
  //     pmId: 0,
  //     cardOwnerName: '',
  //     cardNumber: '',
  //     expirationDate: '',
  //     cvv: '',
  //   }
  // }

  // resetForm(form?: NgForm) {
  //   if (form != null)
  //     form.resetForm();
  //   this.myservice.formData =
  //   {
  //     user: 0,
  //     taskName: '',
  //     taskDescription: '',
  //     startDate:'',
  //     cvv: '',
  //   }
  // }

 
}
