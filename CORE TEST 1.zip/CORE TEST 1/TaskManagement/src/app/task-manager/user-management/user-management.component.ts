import { Component, OnInit } from '@angular/core';
import { TaskManagement } from 'src/app/shared/task-management.model';
import { TaskManagementService } from 'src/app/shared/task-management.service';
import { UserManagementService } from 'src/app/shared/user-management.service';
import { HttpClientModule } from '@angular/common/http';
import { UserManagement } from 'src/app/shared/user-management.model';

@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.css']
})
export class UserManagementComponent implements OnInit {
  isChecked = false;
  formData: TaskManagement = new TaskManagement();
  list: UserManagement[];




  constructor(private http: HttpClientModule, public myservice: UserManagementService, public myservicetask: TaskManagementService) { }

  ngOnInit(): void {
    this.myservice.GetUsers();
    // if(this.myservice.list.user ==true)
    // {
    //   return this.myservicetask.GetTasks();
    // }

  }

  // Gettasks() {
  //   this.http.get(this.rootURL + 'UserTasks')
  //     .toPromise()
  //     .then(res => this.list = res as TaskManagement[])
  // }


  getTaskByUserId($event, userId) {
    this.myservicetask.getTaskByUserId($event, userId);
  }

  // }


}
