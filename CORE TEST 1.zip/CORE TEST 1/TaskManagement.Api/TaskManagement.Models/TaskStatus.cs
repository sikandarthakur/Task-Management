﻿namespace TaskManagement.Models
{
    public enum TaskStatus
    {
        Active = 0,
        Expired = 1
    }
}
