﻿using Microsoft.EntityFrameworkCore;
using TaskManagement.Models;

namespace TaskManagement.Api.Repository
{
    /// <summary>
    /// Task Management DBContext
    /// </summary>
    public class TaskManagementDBContext : DbContext
    {
        public TaskManagementDBContext(DbContextOptions<TaskManagementDBContext> dbContextOptions) : base(dbContextOptions) { }
        protected override void OnConfiguring(DbContextOptionsBuilder dbContextOptionsBuilder)
        {
            dbContextOptionsBuilder.EnableSensitiveDataLogging();
        }
        public DbSet<User> Users { get; set; }
        public DbSet<UserTask> UserTasks { get; set; }

        /// <summary>
        /// OnModelCreating function for adding seed data
        /// </summary>
        /// <param name="modelBuilder"></param>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().HasData(new User { UserId = 1, Firstname = "Aditi", Lastname = "Ozarkar" });
            modelBuilder.Entity<User>().HasData(new User { UserId = 2, Firstname = "Sikandar", Lastname = "Thakur" });
            modelBuilder.Entity<User>().HasData(new User { UserId = 3, Firstname = "Yash", Lastname = "Sonawane" });
            modelBuilder.Entity<User>().HasData(new User { UserId = 4, Firstname = "Varad", Lastname = "Kale" });
            modelBuilder.Entity<User>().HasData(new User { UserId = 5, Firstname = "Pranali", Lastname = "Yeole" });
            modelBuilder.Entity<User>().HasData(new User { UserId = 6, Firstname = "Jyotsna", Lastname = "Belgaonkar" });
            modelBuilder.Entity<User>().HasData(new User { UserId = 7, Firstname = "Kalpesh", Lastname = "Patil" });
            modelBuilder.Entity<User>().HasData(new User { UserId = 8, Firstname = "Shamli", Lastname = "Ambekar" });
            modelBuilder.Entity<User>().HasData(new User { UserId = 9, Firstname = "Vaishnavi", Lastname = "Rana" });
            modelBuilder.Entity<User>().HasData(new User { UserId = 10, Firstname = "Karan", Lastname = "Sadhwani" });
        }
    }
}
