﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TaskManagement.Models;
using TaskStatus = TaskManagement.Models.TaskStatus;

namespace TaskManagement.Api.Repository
{
    public class UserTaskRepository : IUserTask
    {
        private readonly TaskManagementDBContext _context;

        /// <summary>
        /// TaskManagementDBContext Dependency Injection
        /// </summary>
        /// <param name="context"></param>
        public UserTaskRepository(TaskManagementDBContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Create new Task
        /// </summary>
        /// <param name="userTask"></param>
        /// <returns></returns>
        public async Task<UserTask> CreateTask(TaskViewModel taskViewModel)
        {
            UserTask userTask = new UserTask
            {
                TaskName = taskViewModel.TaskName,
                TaskDescription = taskViewModel.TaskDescription,
                StartDate = taskViewModel.StartDate,
                EndDate = taskViewModel.EndDate,
                IsOpen = taskViewModel.IsOpen,
                Status = taskViewModel.Status
            };
            var addTask = await _context.UserTasks.AddAsync(userTask);
            await _context.SaveChangesAsync();
            return addTask.Entity;
        }

        /// <summary>
        /// Delete Task
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<UserTask> DeleteTask(int id)
        {
            var selectedTask = await _context.UserTasks.FindAsync(id);
            _context.UserTasks.Remove(selectedTask);
            await _context.SaveChangesAsync();
            return selectedTask;
        }

        /// <summary>
        /// Get All Task
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<ReadTask>> GetTasks()
        {
            return await _context.UserTasks.Select(s => new ReadTask
            {
                TaskId = s.TaskId,
                TaskName = s.TaskName,
                TaskDescription = s.TaskDescription,
                StartDate = s.StartDate,
                EndDate = s.EndDate,
                IsOpen = s.IsOpen,
                Status = s.Status,
                UserId = s.User.UserId
            }).ToListAsync();
        }

        /// <summary>
        /// Update Task
        /// </summary>
        /// <param name="id"></param>
        /// <param name="userTask"></param>
        /// <returns></returns>
        public async Task<UserTask> UpdateTask(int id, TaskViewModel taskViewModel)
        {
            UserTask userTask = new UserTask
            {
                TaskName = taskViewModel.TaskName,
                TaskDescription = taskViewModel.TaskDescription,
                StartDate = taskViewModel.StartDate,
                EndDate = taskViewModel.EndDate,
                IsOpen = taskViewModel.IsOpen,
                Status = taskViewModel.Status
            };
            var selectedTask = await _context.UserTasks.FirstOrDefaultAsync(x => x.TaskId == id);
            if (selectedTask != null)
            {
                selectedTask.TaskName = userTask.TaskName;
                selectedTask.TaskDescription = userTask.TaskDescription;
                selectedTask.StartDate = userTask.StartDate;
                selectedTask.EndDate = userTask.EndDate;
                selectedTask.IsOpen = true;
                selectedTask.Status = TaskStatus.Active.ToString();
            }
            _context.SaveChanges();
            return selectedTask;
        }

        /// <summary>
        /// Get Task by Id
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        public async Task<ReadTask> GetTask(int taskId)
        {

            return await _context.UserTasks.Select(s => new ReadTask()
            {
                TaskId = s.TaskId,
                TaskName = s.TaskName,
                TaskDescription = s.TaskDescription,
                StartDate = s.StartDate,
                EndDate = s.EndDate,
                IsOpen = true,
                Status = TaskStatus.Active.ToString(),
                UserId = s.User.UserId
            }).FirstOrDefaultAsync(x => x.TaskId == taskId);
        }
    }
}
