﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using TaskManagement.Models;

namespace TaskManagement.Api.Repository
{
    public class UserRepository : IUser
    {
        private readonly TaskManagementDBContext _context;

        /// <summary>
        /// TaskManagementDBContext Dependency Injection
        /// </summary>
        /// <param name="db"></param>
        public UserRepository(TaskManagementDBContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Get all Users
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<User>> GetUsers()
        {
            return await _context.Users.ToListAsync();
        }
    }
}
