﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TaskManagement.Models;

namespace TaskManagement.Api.Repository
{
    public interface IUserTask
    {
        Task<IEnumerable<ReadTask>> GetTasks();
        Task<UserTask> CreateTask(TaskViewModel taskViewModel);
        Task<UserTask> UpdateTask(int id, TaskViewModel taskViewModel);
        Task<UserTask> DeleteTask(int id);
        Task<ReadTask> GetTask(int taskId);
    }
}
