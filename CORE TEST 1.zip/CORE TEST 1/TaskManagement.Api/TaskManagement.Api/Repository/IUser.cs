﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TaskManagement.Models;

namespace TaskManagement.Api.Repository
{
    public interface IUser
    {
        Task<IEnumerable<User>> GetUsers();
    }
}
