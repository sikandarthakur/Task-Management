﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TaskManagement.Api.Repository;
using TaskManagement.Models;

namespace TaskManagement.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserTasksController : ControllerBase
    {
        private readonly IUserTask _db;

        /// <summary>
        /// IUserTask Interface Dependency Injection
        /// </summary>
        /// <param name="db"></param>
        public UserTasksController(IUserTask db)
        {
            _db = db;
        }

        #region CRUD Operations for Task
        /// <summary>
        /// Get All Task
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ReadTask>>> GetTasks()
        {
            try
            {
                return Ok(await _db.GetTasks());
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error retrieving all task data from the database");
            }
        }

        /// <summary>
        /// Create new Task
        /// </summary>
        /// <param name="userTask"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ActionResult<IEnumerable<UserTask>>> CreateTask(TaskViewModel taskViewModel)
        {
            try
            {
                await _db.CreateTask(taskViewModel);

                return CreatedAtAction("GetTask", new { id = taskViewModel.TaskId }, taskViewModel);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error while adding Task to the database");
            }
        }

        /// <summary>
        /// Update Task
        /// </summary>
        /// <param name="id"></param>
        /// <param name="userTask"></param>
        /// <returns></returns>
        [HttpPut("{id}")]
        public async Task<ActionResult<IEnumerable<UserTask>>> UpdateTask(int id, TaskViewModel taskViewModel)
        {
            var updatedTask = await _db.UpdateTask(id, taskViewModel);
            if (updatedTask != null)
            {
                return Ok(updatedTask);
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error while Updating task in database");
            }

        }

        /// <summary>
        /// Delete Task
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        public async Task<ActionResult<IEnumerable<UserTask>>> DeleteTask(int id)
        {
            try
            {
                var seletedTask = await _db.DeleteTask(id);
                return Ok(seletedTask);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status404NotFound, $"Requested Id - {id} not found");
            }
        }

        /// <summary>
        /// Get Task by Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        public async Task<ActionResult<ReadTask>> GetTaskById(int id)
        {
            try
            {
                return Ok(await _db.GetTask(id));
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status404NotFound, "No User Found");
            }
        }
        #endregion
    }
}
