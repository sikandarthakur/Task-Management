USE [TaskManagementDB]
GO
/****** Object:  Table [dbo].[__EFMigrationsHistory]    Script Date: 12/23/2020 5:15:49 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[__EFMigrationsHistory](
	[MigrationId] [nvarchar](150) NOT NULL,
	[ProductVersion] [nvarchar](32) NOT NULL,
 CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY CLUSTERED 
(
	[MigrationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[User]    Script Date: 12/23/2020 5:15:49 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[User](
	[UserId] [int] IDENTITY(1,1) NOT NULL,
	[Firstname] [varchar](50) NOT NULL,
	[Lastname] [varchar](50) NOT NULL,
 CONSTRAINT [PK_User] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserTask]    Script Date: 12/23/2020 5:15:49 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserTask](
	[TaskId] [int] IDENTITY(1,1) NOT NULL,
	[TaskName] [varchar](20) NOT NULL,
	[TaskDescription] [varchar](200) NOT NULL,
	[StartDate] [datetime] NOT NULL,
	[EndDate] [datetime] NOT NULL,
	[IsOpen] [bit] NOT NULL,
	[Status] [varchar](20) NOT NULL,
	[UserId] [int] NULL,
 CONSTRAINT [PK_UserTask] PRIMARY KEY CLUSTERED 
(
	[TaskId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
INSERT [dbo].[__EFMigrationsHistory] ([MigrationId], [ProductVersion]) VALUES (N'20201222061026_initial', N'3.1.10')
GO
SET IDENTITY_INSERT [dbo].[User] ON 
GO
INSERT [dbo].[User] ([UserId], [Firstname], [Lastname]) VALUES (1, N'Aditi', N'Ozarkar')
GO
INSERT [dbo].[User] ([UserId], [Firstname], [Lastname]) VALUES (2, N'Sikandar', N'Thakur')
GO
INSERT [dbo].[User] ([UserId], [Firstname], [Lastname]) VALUES (3, N'Yash', N'Sonawane')
GO
INSERT [dbo].[User] ([UserId], [Firstname], [Lastname]) VALUES (4, N'Varad', N'Kale')
GO
INSERT [dbo].[User] ([UserId], [Firstname], [Lastname]) VALUES (5, N'Pranali', N'Yeole')
GO
INSERT [dbo].[User] ([UserId], [Firstname], [Lastname]) VALUES (6, N'Jyotsna', N'Belgaonkar')
GO
INSERT [dbo].[User] ([UserId], [Firstname], [Lastname]) VALUES (7, N'Kalpesh', N'Patil')
GO
INSERT [dbo].[User] ([UserId], [Firstname], [Lastname]) VALUES (8, N'Shamli', N'Ambekar')
GO
INSERT [dbo].[User] ([UserId], [Firstname], [Lastname]) VALUES (9, N'Vaishnavi', N'Rana')
GO
INSERT [dbo].[User] ([UserId], [Firstname], [Lastname]) VALUES (10, N'Karan', N'Sadhwani')
GO
SET IDENTITY_INSERT [dbo].[User] OFF
GO
SET IDENTITY_INSERT [dbo].[UserTask] ON 
GO
INSERT [dbo].[UserTask] ([TaskId], [TaskName], [TaskDescription], [StartDate], [EndDate], [IsOpen], [Status], [UserId]) VALUES (8, N'Task 1', N'Do this assignment today', CAST(N'1900-01-01T00:00:00.000' AS DateTime), CAST(N'1900-01-01T00:00:00.000' AS DateTime), 1, N'active', 1)
GO
INSERT [dbo].[UserTask] ([TaskId], [TaskName], [TaskDescription], [StartDate], [EndDate], [IsOpen], [Status], [UserId]) VALUES (9, N'Task 2', N'This is task 2', CAST(N'1900-01-01T00:00:00.000' AS DateTime), CAST(N'1900-01-01T00:00:00.000' AS DateTime), 1, N'active', 2)
GO
INSERT [dbo].[UserTask] ([TaskId], [TaskName], [TaskDescription], [StartDate], [EndDate], [IsOpen], [Status], [UserId]) VALUES (10, N'Task 3', N'Complete this Module', CAST(N'1900-01-01T00:00:00.000' AS DateTime), CAST(N'1900-01-01T00:00:00.000' AS DateTime), 1, N'active', 3)
GO
INSERT [dbo].[UserTask] ([TaskId], [TaskName], [TaskDescription], [StartDate], [EndDate], [IsOpen], [Status], [UserId]) VALUES (11, N'Task 4', N'Do this assignment', CAST(N'1900-01-01T00:00:00.000' AS DateTime), CAST(N'1900-01-01T00:00:00.000' AS DateTime), 1, N'active', 1)
GO
SET IDENTITY_INSERT [dbo].[UserTask] OFF
GO
ALTER TABLE [dbo].[UserTask]  WITH CHECK ADD  CONSTRAINT [FK_UserTask_User_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[User] ([UserId])
GO
ALTER TABLE [dbo].[UserTask] CHECK CONSTRAINT [FK_UserTask_User_UserId]
GO
